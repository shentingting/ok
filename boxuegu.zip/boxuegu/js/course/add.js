define(['jquery', 'common', 'nprogress'], function($, undefined, nprogress) {
	
	// 该页所有的js加载完毕，进度条结束。
	nprogress.done();
});
